namespace KMSEmulator.RPC.Bind
{
    class RpcBindRequest : RpcBindMessageBase
    {
        public uint NumCtxItems { get; set; }
    }
}
